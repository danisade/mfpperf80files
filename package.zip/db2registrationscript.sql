CREATE PROCEDURE REGISTER_CLIENTS ()
LANGUAGE SQL
DYNAMIC RESULT SETS 1
P1: BEGIN
DECLARE COUNT INTEGER DEFAULT 400000;
DECLARE N INT DEFAULT 600000;
WHILE COUNT < N DO
SET COUNT = COUNT + 1;
insert into MFP_PERSISTENT_DATA values (COUNT, REPLACE('{"clientId":"CLIENT_NUM","registrationData":{"application":{"id":"com.sample.oauthdemoandroid","clientPlatform":"android","version":"1.0"},"device":{"id":"device_CLIENT_NUM","model":"sdk_phone_armv7","os":"android 5.0.2","deviceDisplayName":null,"deviceStatus":"ACTIVE"}, "attributes":["java.util.LinkedHashMap",{}]},"signatureAlgorithm":"RS256","publicCredentials":["java.security.interfaces.RSAPublicKey",{"kty":"RSA","n":"AJqHV9w5pYsoIQ_INnOFspIMAsZHxKgkEf_VsMC2CYXq5KeFdg0cuCE-AbGqu6TXEDHXaTh_YtUBaQz06HDZqOeKmmE-ESypdZtAxPg56E5QKIDupWtaMWlxw-fScKAD30RT_E_GkkfdK3IEckWZ1gM1tvVCx_3YQ4Cxtxg-I6LJ","e":"AQAB"}],"privateCredentials":null,"registrationComplete":true,"enabled":true,"remoteDisableNotifyId":0,"lastActivityTime":1462785710974,"associatedUsers":["java.util.HashMap",{}],"publicAttributes":{"attributes":{}},"protectedAttributes":{"attributes":{}}}', 'CLIENT_NUM', COUNT), '28f042d9-2b86-3285-8afb-b9aae7faf1bc', NULL, 0, 'com.sample.oauthdemoandroid', '1.0', 1, '[]', 0, 'hash');
end while;
END P1